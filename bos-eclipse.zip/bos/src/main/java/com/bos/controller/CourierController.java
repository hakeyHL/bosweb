package com.bos.controller;

import com.bos.model.Courier;
import com.bos.model.Order;
import com.bos.service.CourierService;
import com.bos.service.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by linux on 2017骞�03鏈�18鏃�.
 * Time 09:02
 */
@Controller
@RequestMapping("courier")//璇锋眰璺緞鏄犲皠
public class CourierController extends BaseController {
    //娉ㄥ叆service
    @Resource
    private CourierService courierService;
    @Resource
    private OrderService orderService;

    //璇锋眰璺緞鏄犲皠,鍔犱笂绫讳笂鐨勬娉ㄨВ,姝ゆ帴鍙ｇ殑瀹屾暣璁块棶璺緞涓�
    //ip:绔彛/courier/list
    @RequestMapping("list")
    //鑾峰彇蹇�掑憳鍒楄〃
    public ModelAndView listCouriers(Courier courier) {
        if (courier != null) {
            modelAndView.addObject("car", courier);
        }
        List<Courier> couriers = courierService.listCouriers(courier.getName());
        modelAndView.addObject("couriers", couriers);
        modelAndView.setViewName("layout/courier/list");
        return modelAndView;
    }

    //澧炲姞涓�涓揩閫掑憳
    @RequestMapping("add")
    public ModelAndView addCourier(Courier courier) {
        courierService.addCourier(courier);
        //澧炲姞瀹屼箣鍚庤繑鍥炲揩閫掑憳鍒楄〃椤甸潰,鎵�浠ヨ皟鐢ㄦ湰绫籰istCouriers鏂规硶
        return this.listCouriers(new Courier());
    }


    //鍒犻櫎涓�涓揩閫掑憳
    @RequestMapping("del/{id}")
    public ModelAndView delCourier(@PathVariable(value = "id") int id) {
        courierService.delCourier(id);
        //杩斿洖蹇�掑憳鍒楄〃椤甸潰,鎵�浠ヨ皟鐢ㄦ湰绫籰istCouriers鏂规硶
        return this.listCouriers(new Courier());
    }

    //鍒犻櫎澶氫釜蹇�掑憳
    @ResponseBody
    @RequestMapping("batchDelete")
    public boolean batchDelCourier(@RequestParam(value = "ids[]") int[] ids) {
        courierService.batchDelCourier(ids);
        return true;
    }

    //淇敼蹇�掑憳淇℃伅
    @RequestMapping("update")
    public RedirectView updateCourier(Courier courier) {
    	String contextPath = request.getContextPath();
        if (courier.getId() == null) {
            this.addCourier(courier);
        } else {
            courierService.updateCourier(courier);
        }
        //閲嶅畾鍚戝埌蹇�掑憳鍒楄〃椤甸潰
        return new RedirectView(contextPath+"/courier/list");
    }

    /**
     * 鑾峰彇蹇�掑憳淇℃伅
     *
     * @param id 蹇�掑憳id
     */
    @RequestMapping("info/{id}")
    public ModelAndView getCourierInfo(@PathVariable(value = "id") int id) {
        modelAndView.setViewName("layout/courier/edit");
        if (id <= 0) {
            //濡傛灉id灏忎簬绛変簬0璺宠浆鍒扮紪杈戦〉闈�,琛ㄧず娣诲姞蹇�掑憳
            return modelAndView;
        }
        Courier courier = courierService.getCourierById(id);
        modelAndView.addObject("courier", courier);

        List<Order> orders = orderService.getOrdersByCourierId(id);
        modelAndView.addObject("orders", orders);
        return modelAndView;
    }
}
