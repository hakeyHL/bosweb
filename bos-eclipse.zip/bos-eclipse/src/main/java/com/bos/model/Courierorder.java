package com.bos.model;

public class Courierorder {
    private Integer id;

    private Integer courierid;

    private Integer orderid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCourierid() {
        return courierid;
    }

    public void setCourierid(Integer courierid) {
        this.courierid = courierid;
    }

    public Integer getOrderid() {
        return orderid;
    }

    public void setOrderid(Integer orderid) {
        this.orderid = orderid;
    }
}